

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.Scanner;
import java.io.File;
import java.lang.management.ManagementFactory;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import com.sun.management.OperatingSystemMXBean;

/**
 * Created by amazing on 2017/9/30.
 */

class EntropySupply implements Runnable
{
	Accumulator accumulator;
	private Thread t;

	public EntropySupply(Accumulator accumulator)
	{
		this.accumulator = accumulator;
	}
	public void run()
	{
		while (true){
			String time = getTime();
			String mem_str = getMemInfo();
			String cpu_usage = getCPU();
			//System.out.println(time+mem_str+cpu_usage);
			// full pool
			if(this.accumulator.prng.string_pool[31].length() >= 192){
				for(int i = 0; i < 31; i++)
					this.accumulator.prng.string_pool[i] = "";
			}
			for (int i = 0; i < 32;i++){
				if(this.accumulator.prng.string_pool[i].length() < 192){
					//System.out.println("233");
					this.accumulator.AddRandomEvent(this.accumulator.prng,0,i,new String(this.accumulator.generator.SHA(time.getBytes(),"SHA-256")));
					this.accumulator.AddRandomEvent(this.accumulator.prng,1,i,new String(this.accumulator.generator.SHA(mem_str.getBytes(),"SHA-256")));
					this.accumulator.AddRandomEvent(this.accumulator.prng,2,i,new String(this.accumulator.generator.SHA(cpu_usage.getBytes(),"SHA-256")));
					//System.out.println(this.accumulator.prng.string_pool[i]);

					break;
				}
				//System.out.println(this.accumulator.prng.string_pool[i]);
			}
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}


	}
	public void start()
	{
//		System.out.println("dshj");
		if(t == null){
			t = new Thread(this);
			t.start();
		}
	}

	private static String substring(String src, int start_idx, int end_idx) {
		byte[] b = src.getBytes();
		String tgt = "";
		for (int i = start_idx; i <= end_idx; i++) {
			tgt += (char) b[i];
		}
		return tgt;
	}

	public static String getMemInfo()
	{
		OperatingSystemMXBean mem = (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
		float usage = mem.getFreePhysicalMemorySize() * 100 / mem.getTotalPhysicalMemorySize();
		return Float.toString(usage);
	}


	public static String getTime()
	{
		long time = System.nanoTime();
		return Long.toString(time);
	}

	private static long[] readCpu(final Process proc) {
		long[] retn = new long[2];
		try {
			proc.getOutputStream().close();
			InputStreamReader ir = new InputStreamReader(proc.getInputStream());
			LineNumberReader input = new LineNumberReader(ir);
			String line = input.readLine();
			if (line == null || line.length() < 10) {
				return null;
			}
			int capidx = line.indexOf("Caption");
			int cmdidx = line.indexOf("CommandLine");
			int rocidx = line.indexOf("ReadOperationCount");
			int umtidx = line.indexOf("UserModeTime");
			int kmtidx = line.indexOf("KernelModeTime");
			int wocidx = line.indexOf("WriteOperationCount");
			long idletime = 0;
			long kneltime = 0;
			long usertime = 0;
			while ((line = input.readLine()) != null) {
				if (line.length() < wocidx) {
					continue;
				}
				// �ֶγ���˳��Caption,CommandLine,KernelModeTime,ReadOperationCount,
				// ThreadCount,UserModeTime,WriteOperation
				String caption = substring(line, capidx, cmdidx - 1).trim();
				String cmd = substring(line, cmdidx, kmtidx - 1).trim();
				if (cmd.indexOf("wmic.exe") >= 0) {
					continue;
				}
				String s1 = substring(line, kmtidx, rocidx - 1).trim();
				String s2 = substring(line, umtidx, wocidx - 1).trim();
				if (caption.equals("System Idle Process")
						|| caption.equals("System")) {
					if (s1.length() > 0)
						idletime += Long.valueOf(s1).longValue();
					if (s2.length() > 0)
						idletime += Long.valueOf(s2).longValue();
					continue;
				}
				if (s1.length() > 0)
					kneltime += Long.valueOf(s1).longValue();
				if (s2.length() > 0)
					usertime += Long.valueOf(s2).longValue();
			}
			retn[0] = idletime;
			retn[1] = kneltime + usertime;
			return retn;
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				proc.getInputStream().close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public String getCPU()
	{
		//get cpu usage
		String cpu_usage = "";
		try {
			String procCmd = System.getenv("windir")
					+ "//system32//wbem//wmic.exe process get Caption,CommandLine,KernelModeTime,ReadOperationCount,ThreadCount,UserModeTime,WriteOperationCount";
			// ȡ������Ϣ
			long[] c0 = readCpu(Runtime.getRuntime().exec(procCmd));
			Thread.sleep(1);
			long[] c1 = readCpu(Runtime.getRuntime().exec(procCmd));
			if (c0 != null && c1 != null) {
				long idletime = c1[0] - c0[0];
				long busytime = c1[1] - c0[1];
				cpu_usage = Double.toString(100 * (busytime) * 1.0 / (busytime + idletime));
			} else {
				cpu_usage = "0";
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return cpu_usage;
	}
}


