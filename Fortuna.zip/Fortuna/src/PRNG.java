import java.util.Arrays;

/**
 * Created by amazing on 2018/4/18.
 */
public class PRNG {
    byte[] g;
    long ReseedCnt;
    String[] string_pool;
    public PRNG InitialPRNG(byte[] g, long ReseedCnt, String[] string_pool)
    {
        this.g = Arrays.copyOfRange(g,0,g.length);
        this.ReseedCnt = ReseedCnt;
        this.string_pool = (String[])string_pool.clone();
        return this;
    }
}
