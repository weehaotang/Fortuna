import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

/**
 * Created by amazing on 2018/4/19.
 */
public class Service implements Runnable{
    Thread t;
    private boolean runFlag = true;
    private ServerSocket ss;

    public Service() throws IOException {
        ss = new ServerSocket(8090);
        // �������һ���˿ں�8090ʹ�ÿͻ��˿�������
    }

    public synchronized void setRunFlag(boolean runFlag)
    {
        this.runFlag = runFlag;
    }

    private synchronized boolean getRunFlag()
    {
        return runFlag;
    }

    public void run()
    {
        Socket socket = null;
        try {
            //socket ͨ��
            socket = ss.accept();
            // ���ܿͻ��˵�����
            InputStream is = socket.getInputStream();
            // ��ÿͻ��˵�������
            int len = 0;
            byte[] b = new byte[1024];
            int random_length = 64;
            while ((len = is.read(b)) != -1) {
                String str = new String(b, 0, len);
                System.out.println(str);
                random_length = Integer.valueOf(str.replace("\n",""));
            }
            OutputStream os = socket.getOutputStream();
            System.out.println("�����߳̿�ʼ����");
            Accumulator accumulator = new Accumulator();
            try {
                accumulator.InitializePRNG();
            } catch (IOException e) {
                e.printStackTrace();
            }
            EntropySupply es = new EntropySupply(accumulator);
            es.start();
            //
            String res = "";
            Date begin = new Date();
            long begin_time = begin.getTime();
            long end_time;
            while (getRunFlag()){
                accumulator = es.accumulator;
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                res = accumulator.RandomData(accumulator.prng,random_length);
                System.out.println("������������ǣ�"+res);
                os.write(res.getBytes());
                end_time = new Date().getTime();
                if((end_time - begin_time) > 1000*60*10){
                    accumulator.UpdateSeedFile(accumulator.filepath);
                    begin_time = end_time;
                }

                //update the file every 10 minutes
            }
            // ͨ���������ͻ��˷������ݡ�
            os.close();
            // socket.shutdownOutput();
            is.close();
            socket.close();
            ss.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("�����߳̽�������");
    }
    public void start()
    {
        if(t == null){
            t = new Thread(this);
            t.start();
        }
    }

}
