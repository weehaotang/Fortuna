/**
 * Created by amazing on 2018/4/17.
 */
import com.sun.crypto.provider.AESKeyGenerator;

import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.util.Arrays;


public class Generator {
    //generate the random numbers
    byte[] state = new byte[48];

    public Generator()
    {
        byte zero = 0;
        byte[] key = new byte[32];
        byte[] counter = new byte[16];
        byte[] state = new byte[48];
        Arrays.fill(key,zero);
        Arrays.fill(counter,zero);
        System.arraycopy(key,0,state,0,key.length);
        System.arraycopy(counter,0,state,key.length,counter.length);
        this.state = state;
    }

    public void test(String test)
    {
        test += "2333";
    }

    public static byte[] SHA(byte[] data, String sha_type)
    {
        // SHA ���ܿ�ʼ
        // �������ܶ��� ������������
        byte byteBuffer[] = {0};
        try {
            MessageDigest messageDigest = MessageDigest.getInstance(sha_type);
            // ����Ҫ���ܵ��ֽڴ�
            messageDigest.update(data);
            // �õ� byte ��ͽ��
            byteBuffer = messageDigest.digest();

        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
        return byteBuffer;
    }

    public static byte[] longToBytes(long x) {
        ByteBuffer buffer = ByteBuffer.allocate(16);
        buffer.putLong(0, x);
        return buffer.array();
    }

    public static long bytesToLong(byte[] bytes) {
        ByteBuffer buffer = ByteBuffer.allocate(16);
        buffer.put(bytes, 0, bytes.length);
        buffer.flip();//need flip
        return buffer.getLong();
    }

    public byte[] Reseed(byte[] state, byte[] seed)
    {
        //calculate new key and new counter
        byte[] temp_key = new byte[32];
        byte[] temp_counter = new byte[16];
        temp_key = Arrays.copyOfRange(state,0,temp_key.length);
        temp_counter = Arrays.copyOfRange(state,temp_key.length,state.length);
        //join key and seed
        byte[] k_s = new byte[temp_key.length+seed.length];
        System.arraycopy(temp_key,0,k_s,0,temp_key.length);
        System.arraycopy(seed,0,k_s,temp_key.length,seed.length);
        //hash
        temp_key = SHA(k_s,"SHA-256");
        //new counter
        long counter_val = bytesToLong(temp_counter);
        counter_val++;
        temp_counter = longToBytes(counter_val);
        //to the new state
        System.arraycopy(temp_key,0,state,0,temp_key.length);
        System.arraycopy(temp_counter,0,state,temp_key.length,temp_counter.length);
        this.state = state;
        return state;
    }

    public String GenerateBlocks(byte[] state, int k)
    {
        //32*k long
        String res = "";
        AES aes = new AES();
        //calculate new key and new counter
        byte[] temp_counter = new byte[16];
        byte[] temp_key = new byte[32];

        long counter_val;
        temp_key = Arrays.copyOfRange(state,0,temp_key.length);
        temp_counter = Arrays.copyOfRange(state,temp_key.length,state.length);
        //System.out.println(temp_counter.length);
        //System.out.println(temp_key.length);
        String data = new String(temp_counter);
        String key = new String(temp_key);
        try {
            for (int i = 0;i < k; i++)
            {
                res = res + aes.encrypt(data,key);
                //System.out.println(res);
                counter_val = bytesToLong(temp_counter);
                counter_val++;
                temp_counter = longToBytes(counter_val);
                data = new String(temp_counter);
            }
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
        //change state
        //to the new state
        System.arraycopy(temp_key,0,state,0,temp_key.length);
        System.arraycopy(temp_counter,0,state,temp_key.length,temp_counter.length);
        this.state = state;
        return res;
    }

    public String PseudoRandomData(byte[] state, int n)
    {
        byte[] temp_key = new byte[32];
        int k = n / 16;
        int spare = n - k * 16;
        if(spare > 0)
            k++;
        //get result
        //System.out.println(k);
        String res;
        //System.out.println(GenerateBlocks(state,k).length());
        res = GenerateBlocks(state,k).substring(0,n);
        //get a new key
        //System.out.println(temp_key.length);
        temp_key = GenerateBlocks(state,2).getBytes();
        //update state
        System.arraycopy(temp_key,0,state,0,temp_key.length);
        this.state = state;
        return res;
    }
}
