import com.sun.management.OperatingSystemMXBean;
import sun.security.x509.GeneralName;

import java.io.*;
import java.lang.management.ManagementFactory;
import java.util.Date;

/**
 * Created by amazing on 2018/4/16.
 */
public class Accumulator {

    Date date = new Date();
    Generator generator;
    PRNG prng;
    String filepath = "seed.txt";

    public PRNG InitializePRNG() throws IOException {
        PRNG prng = new PRNG();
        //read from file

        String[] string_pool = new String[32];
        for (int i = 0; i < 32; i++)
            string_pool[i] = "";
        long seed_cnt = 0;
        this.generator = new Generator();
        prng.InitialPRNG(this.generator.state,seed_cnt,string_pool);
//        if(prng == null)
//            System.out.println("66666");
        this.WriteSeedFile(prng,filepath);
        this.prng = prng;
        return prng;
    }

    public String RandomData(PRNG prng, int n)
    {

        int MinPoolSize = 64;
        long begin = this.date.getTime();

        long end = new Date().getTime();
        if(prng.string_pool[0].length() > MinPoolSize && (end-begin > 100)){
            prng.ReseedCnt++;
            String seed = "";
            for(int i = 0; i < 32; i++){
                if(prng.ReseedCnt % (long)Math.pow(2,i) == 0){
                    seed += new String(Generator.SHA(prng.string_pool[i].getBytes(),"SHA-256"));
                    prng.string_pool[i] = "";
                }
            }
        generator.Reseed(prng.g,seed.getBytes());
        this.date = new Date();
        }
        this.prng = prng;
        return generator.PseudoRandomData(prng.g,n);
    }

    public void AddRandomEvent(PRNG prng, int entropy_number, int pool_number, String data)
    {
        if(data.length()<=32 && data.length()>=1 && entropy_number>=0 && entropy_number<=255 && pool_number>=0 && pool_number<=31){
            //add event
            prng.string_pool[pool_number] = prng.string_pool[pool_number] + String.valueOf(entropy_number)+data.length()+data;
        }
    }

    public void WriteSeedFile(PRNG prng, String filepath) throws IOException {
        FileWriter fw = new FileWriter(filepath);
        BufferedWriter bw = new BufferedWriter(fw);
        String data = RandomData(prng,64);
        bw.write(data);
        this.prng = prng;
    }

    public void UpdateSeedFile(String filepath)
    {
        String seed = "";
        try{
            BufferedReader br = new BufferedReader(new FileReader(filepath));
            seed = br.readLine();
            this.generator.Reseed(this.prng.g,seed.getBytes());
            br.close();
            String res = RandomData(this.prng,64);
            BufferedWriter bw = new BufferedWriter(new FileWriter(filepath));
            bw.write(res);
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
}
