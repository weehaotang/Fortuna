/**
 * Created by amazing on 2018/4/19.
 */
public class Main {
    public static void main(String[] args) throws Exception {
        Client cl = new Client();
        cl.client();
    }

}
