import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;

/**
 * Created by amazing on 2018/4/19.
 */
public class Client {
    public void client() throws Exception {
        Socket socket = new Socket(InetAddress.getLocalHost(), 8090);
        OutputStream os = socket.getOutputStream();
        String len_str = "";
        BufferedReader buf = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("please input the length of the random data");
        len_str = buf.readLine();
        os.write(len_str.getBytes());
        socket.shutdownOutput();
        // �ر����������������رյĻ�����˲���֪�����ݴ����Ѿ���������һֱ�ȴ���
        InputStream is = socket.getInputStream();
        int len = 0;
        byte[] b = new byte[1024];
        while ((len = is.read(b)) != -1) {
            String str = new String(b, 0, len);
            System.out.println(str);
        }
        is.close();
        os.close();
        socket.close();
    }
}
